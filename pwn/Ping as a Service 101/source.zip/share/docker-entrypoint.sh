#!/bin/sh
chmod +x /home/web/www/cgi-bin/mainfunctions.cgi
service lighttpd start && sleep infinity